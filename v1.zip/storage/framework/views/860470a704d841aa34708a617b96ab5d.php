<?php if(true): ?>
    <section id="faq-wrapper">    
        <div class="container pt-7">

            <div class="row text-center mb-8 mt-7">
                <div class="col-md-12 title">
                    <h6><?php echo e(__('Frequently Asked')); ?> <span><?php echo e(__('Questions')); ?></span></h6>
                    <p><?php echo e(__('Got questions? We have you covered.')); ?></p>
                </div>
            </div>

            <div class="row justify-content-md-center">
        
                <?php if($count_faqs>0): ?>

                    <div class="col-md-10">
        
                        <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div id="accordion" data-aos="fade-left" data-aos-delay="300" data-aos-once="true" data-aos-duration="700">
                                <div class="card">
                                    <div class="card-header" id="heading<?php echo e($faq->id); ?>">
                                        <h5 class="mb-0">
                                        <span class="btn btn-link" data-bs-toggle="collapse" data-bs-target="#collapse-<?php echo e($faq->id); ?>" aria-expanded="false" aria-controls="collapse-<?php echo e($faq->id); ?>">
                                            <?php echo e(__($faq->question)); ?>

                                        </span>
                                        </h5>
                                    </div>
                                        
                                    <div id="collapse-<?php echo e($faq->id); ?>" class="collapse" aria-labelledby="heading<?php echo e($faq->id); ?>" data-bs-parent="#accordion">
                                        <div class="card-body">
                                            <?php echo __($faq->answer); ?>

                                        </div>
                                    </div>
                                </div>
                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                <?php else: ?>
                    <div class="row text-center">
                        <div class="col-sm-12 mt-6 mb-6">
                            <h6 class="fs-12 font-weight-bold text-center"><?php echo e(__('No FAQ answers were published yet')); ?></h6>
                        </div>
                    </div>
                <?php endif; ?>
            
            </div>        
        </div>
        
    </section> <!-- END SECTION FAQ -->
<?php endif; ?><?php /**PATH /home/youssef/Desktop/laravel/projects/intelOmega/resources/views/faqs.blade.php ENDPATH**/ ?>