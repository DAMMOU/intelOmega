<?php if($message = Session::get('success')): ?>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
        const Toast = Swal.mixin({
            toast: true,
            position: "center", // Change this line to set the position
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
        });
        Toast.fire({
            icon: "success",
            title: "<?php echo e($message); ?>"
        });
    });
    </script>
<?php endif; ?>

<?php if($message = Session::get('error')): ?>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
        const Toast = Swal.mixin({
            toast: true,
            position: "top-right", // Change this line to set the position
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
        });
        Toast.fire({
            icon: "error",
            title: "<?php echo e($message); ?>"
        });
    });
    </script>
<?php endif; ?>
<?php if($message = Session::get('warning')): ?>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
        const Toast = Swal.mixin({
            toast: true,
            position: "top-right", // Change this line to set the position
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
        });
        Toast.fire({
            icon: "warning",
            title: "<?php echo e($message); ?>"
        });
    });
    </script>
<?php endif; ?>

<?php if($message = Session::get('info')): ?>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
        const Toast = Swal.mixin({
            toast: true,
            position: "bottom-end", // Change this line to set the position
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
        });
        Toast.fire({
            icon: "info",
            title: "<?php echo e($message); ?>"
        });
    });
    </script>
<?php endif; ?>


<?php /**PATH /home/youssef/Desktop/laravel/projects/intelOmega/resources/views/layouts/flash.blade.php ENDPATH**/ ?>