<?php $__env->startSection('content'); ?>
    <section id="main-wrapper">
        
        <div class="h-100vh justify-center min-h-screen">

                <div class="row h-100vh vertical-center">
                    <div class="col-sm-12">
                        <div class="text-container text-center">

                            <h3 class="mb-4 font-weight-bold text-white"><?php echo e(__('Meet')); ?>, <?php echo e(config('app.name')); ?></h3>
                            <h1 class=" text-white" ><?php echo e(__('The Future of Writing')); ?></h1>

                            <h1 class=" mb-0 gradient fixed-height" id="typed"></h1>

                            <p class="fs-18 text-white "><?php echo e(__('Let AI create content for blogs, articles, websites, social media and more')); ?></p> 

                            <a href="#" class="btn btn-primary special-action-button"><?php echo e(__('Try Now For Free')); ?></a>

                        </div>
                    </div>                                
                </div>           
        </div>
    </section>

<?php $__env->stopSection(); ?>


      
        
       
        
       
    


<?php echo $__env->make('layouts.master-frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/youssef/Desktop/laravel/projects/intelOmega/resources/views/home.blade.php ENDPATH**/ ?>