<?php if(true): ?>
    <section id="blog-wrapper">

        <div class="container text-center">

            <!-- BLOG TITLE -->
            <div class="row mb-8 mt-5">

                <div class="title w-100">
                    <h6><span><?php echo e(__('Latest')); ?></span> <?php echo e(__('Blogs')); ?></h6>
                        <p><?php echo e(__('Read our unique blog articles about various data archiving solutions and secrets')); ?></p>
                    </div>

            </div> <!-- END BLOG TITLE -->

            <?php if($count_blogs > 0): ?>
                        
                        <!-- BLOGS -->
                        <div class="row" id="blogs">
                            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="blog" data-aos="zoom-in" data-aos-delay="500" data-aos-once="true" data-aos-duration="1000">			
                                <div class="blog-box">
                                    <div class="blog-img">
                                        
                                        <a href="#"><img src="<?php echo e(URL::asset('img/files/01.png')); ?>" alt="Blog Image"></a>
                                    </div>
                                    <div class="blog-info">
                                        <h6 class="blog-date text-left text-muted mt-3 pt-1 mb-4"><span class="mr-2"><?php echo e($blog->created_by); ?></span> | <i class="mdi mdi-alarm mr-2"></i><?php echo e(date('j F Y', strtotime($blog->created_at))); ?></h6>
                                        <h5 class="blog-title fs-16 text-left mb-3"><?php echo e(__($blog->title)); ?></h5>                                     
                                    </div>
                                </div>                        
                            </div> 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div> 
                        

                        <!-- ROTATORS BUTTONS -->
                        <div class="blogs-nav">
                            <a class="blogs-prev"><i class="fa fa-chevron-left"></i></a>
                            <a class="blogs-next"><i class="fa fa-chevron-right"></i></a>                                
                        </div>

                    <?php else: ?>
                        <div class="row text-center">
                            <div class="col-sm-12 mt-6 mb-6">
                                <h6 class="fs-12 font-weight-bold text-center"><?php echo e(__('No blog articles were published yet')); ?></h6>
                            </div>
                        </div>
                    <?php endif; ?>

                </div> <!-- END CONTAINER -->

                
            </section> <!-- END  BLOGS -->
        <?php endif; ?><?php /**PATH /home/youssef/Desktop/laravel/projects/intelOmega/resources/views/blogs.blade.php ENDPATH**/ ?>