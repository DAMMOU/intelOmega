

<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
	<head>
		<!-- Meta data -->
		<meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="author" content="<?php echo e($information['author']); ?>">
	    <meta name="keywords" content="<?php echo e($information['keywords']); ?>">
	    <meta name="description" content="<?php echo e($information['description']); ?>">
		
        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <!-- Title -->
        <title><?php echo e($information['title']); ?></title>

		<!--Favicon -->
		<link rel="icon" href="<?php echo e(URL::asset('img/brand/favicon.ico')); ?>" type="image/x-icon"/>

		<!-- slick CSS Files -->
        

		<!-- Bootstrap 5.2.3 -->
		<link href="<?php echo e(URL::asset('plugins/bootstrap-5.2.3-dist/css/bootstrap.min.css')); ?>" rel="stylesheet">

		<!-- Icons -->
		<link href="<?php echo e(URL::asset('css/icons.css')); ?>" rel="stylesheet" />
		<link href="<?php echo e(URL::asset('styles/style.css')); ?>" rel="stylesheet" />

	</head>

	<body>
		
		<?php if(config('master-frontend.maintenance') == 'on'): ?>

			<?php echo $__env->make('layouts.maintenance', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<?php else: ?>

			<div class="page">
				<div class="page-main">

					<section id="main-wrapper">
				
						<div class="relative flex items-top justify-center min-h-screen">
							<div class="container-fluid fixed-top" id="navbar-container">
								<div class="container">
									<div class="row">
			
										<nav class="navbar navbar-expand-lg navbar-light w-100" id="navbar-responsive">
											<a class="navbar-brand" href="<?php echo e(route('home')); ?>"><img id="brand-img"  src="<?php echo e(URL::asset('img/brand/logo.png')); ?>" alt=""></a>
											<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
												<span class="navbar-toggler-icon"></span>
											</button>
											<div class="collapse navbar-collapse section-links" id="navbarNav">
												<ul class="navbar-nav">
													<li class="nav-item">
														<a class="nav-link scroll active" href="#main-wrapper"><?php echo e(__('Home')); ?></a>
													</li>		

													<li class="nav-item">
														<a class="nav-link scroll" href="#prices-wrapper"><?php echo e(__('Prices')); ?></a>
													</li>
						
						
													<li class="nav-item">
														<a class="nav-link scroll" href="#blog-wrapper"><?php echo e(__('Blogs')); ?></a>
													</li>
										
											
													<li class="nav-item">
														<a class="nav-link scroll" href="#faq-wrapper"><?php echo e(__('FAQs')); ?></a>
													</li>
											
													
													<li class="nav-item">
														<a class="nav-link scroll" href="#contact-wrapper"><?php echo e(__('Contact Us')); ?></a>
													</li>
												
													
													<li class="nav-item text-center frontend-buttons">
														<div>
																	
															<a href="<?php echo e(route('home')); ?>" class="action-button dashboard-button pl-5 pr-5"><?php echo e(__('Dashboard')); ?></a>
																	
															<a href="<?php echo e(route('home')); ?>" class="btn btn-primary special-action-button" id="login-button"><?php echo e(__('Login')); ?></a>
						
															<a href="<?php echo e(route('home')); ?>" class="ml-2 action-button register-button pl-5 pr-5"><?php echo e(__('Sign Up')); ?></a>
																		
														</div>
													</li>
												</ul>
											</div>
										</nav>
			
									</div>
								</div>
			
			
							</div>
			
						</div>  
					</section>

					<!-- App-Content -->			
					<div class="main-content">
						<div class="side-app">

							<?php echo $__env->make('layouts.maintenance', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
							<?php echo $__env->yieldContent('content'); ?>

						</div>                   
					</div>

				</div>

				
			</div>
			<!-- End Page -->
			<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php endif; ?>

		<!-- JQuery-->
		<script src="<?php echo e(URL::asset('plugins/jquery/jquery-3.6.0.min.js')); ?>"></script>

		<!-- Bootstrap 5-->
		<script src="<?php echo e(URL::asset('plugins/bootstrap-5.2.3-dist/js/bootstrap.bundle.min.js')); ?>"></script>

	</body>
</html>

<?php /**PATH /home/youssef/Desktop/laravel/projects/intelOmega/resources/views/layouts/master-frontend.blade.php ENDPATH**/ ?>