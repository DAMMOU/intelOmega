<?php $__env->startSection('content'); ?>

        <section id="main-wrapper">
            
        </section>
<?php $__env->stopSection(); ?>


        <!-- SECTION - FEATURES
        ========================================================-->
      


        <!-- SECTION - FEATURES - TEMPLATES
        ========================================================-->
    


        <!-- SECTION - CUSTOMER FEEDBACKS
        ========================================================-->
       
        
        
         <!-- SECTION - BANNER
        ========================================================-->
      
        
        
       
        
       
    


<?php echo $__env->make('layouts.master-frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/youssef/Desktop/laravel/projects/intelOmega/resources/views/home.blade.php ENDPATH**/ ?>