<?php

namespace App\Http\Controllers;

use App\Models\Faq;
use App\Models\Review;
use App\Models\Setting;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Show home page
     */
    public function index()
    {
        $information = $this->metadataInformation();
        
        $review_exists = Review::count();   
        $reviews = Review::all();

        $faq_exists = Faq::count();        
        $faqs = Faq::where('status', 'visible')->get();

        
        return view('home', compact('information', 'faqs', 'reviews'));
    }


    public function metadataInformation()
    {
        $information_rows = ['title', 'author', 'keywords', 'description', 'js', 'css'];
        $information = [];
        $settings = Setting::all();

        foreach ($settings as $setting) {
            if (in_array($setting['name'], $information_rows)) {
                $information[$setting['name']] = $setting['value'];
            }
        }

        return $information;
    }
}
