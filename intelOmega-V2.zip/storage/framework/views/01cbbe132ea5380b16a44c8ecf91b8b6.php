<section id="main-wrapper">
				
    <div class="relative flex items-top justify-center min-h-screen">

        <div class="container-fluid fixed-top" id="navbar-container">

            <div class="container">
                
                <div class="row">
                    
                    <nav class="navbar navbar-expand-lg navbar-light w-100" id="navbar-responsive">
                        <a class="navbar-brand" href="<?php echo e(route('home')); ?>"><img id="brand-img"  src="<?php echo e(URL::asset('img/brand/logo.png')); ?>" alt=""></a>
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse section-links" id="navbarNav">
                            <ul class="navbar-nav">
                                <li class="nav-item">
                                    <a class="nav-link scroll active" href="#main-wrapper"><?php echo e(__('Home')); ?></a>
                                </li>		

                                <li class="nav-item">
                                    <a class="nav-link scroll" href="#prices-wrapper"><?php echo e(__('Prices')); ?></a>
                                </li>
    
    
                                <li class="nav-item">
                                    <a class="nav-link scroll" href="#blog-wrapper"><?php echo e(__('Blogs')); ?></a>
                                </li>
                    
                        
                                <li class="nav-item">
                                    <a class="nav-link scroll" href="#faq-wrapper"><?php echo e(__('FAQs')); ?></a>
                                </li>
                        
                                
                                <li class="nav-item">
                                    <a class="nav-link scroll" href="#contact-wrapper"><?php echo e(__('Contact Us')); ?></a>
                                </li>
                            
                                
                                <li class="nav-item text-center frontend-buttons">
                                    <div>
                                                
                                        <a href="<?php echo e(url('/')); ?>" class=" btn btn-dark"><?php echo e(__('Dashboard')); ?></a>
                                                
                                        <a href="<?php echo e(url('/')); ?>" class=" ml-2 btn btn-primary" id="login-button"><?php echo e(__('Login')); ?></a>
    
                                        <a href="<?php echo e(url('/')); ?>" class="btn btn-dark "><?php echo e(__('Sign Up')); ?></a>
                                                    
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </nav>
                   
                </div>
            </div>

            <?php echo $__env->make('layouts.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
        </div>
    </div>  
    
</section><?php /**PATH /home/youssef/Desktop/laravel/projects/intelOmega/resources/views/header.blade.php ENDPATH**/ ?>