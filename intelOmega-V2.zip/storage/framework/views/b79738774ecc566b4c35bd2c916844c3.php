

<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
	<head>
		<!-- Meta data -->
		<meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="author" content="<?php echo e($information['author']); ?>">
	    <meta name="keywords" content="<?php echo e($information['keywords']); ?>">
	    <meta name="description" content="<?php echo e($information['description']); ?>">
		
        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <!-- Title -->
        <title><?php echo e($information['title']); ?></title>

		<!--Favicon -->
		<link rel="icon" href="<?php echo e(URL::asset('img/brand/favicon.ico')); ?>" type="image/x-icon"/>
		<head>
			<!-- ... Autres balises head ... -->
			<script src="https://cdn.jsdelivr.net/npm/typed.js@2.0.12"></script>
		</head>
		
		<!-- slick CSS Files -->
        
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-1ycn6IcaQQ40/MKBW2W4Rhis/DbILU74C1vSrLJxCq57o941Ym01SwNsOMqvEBFlcgUa6xLiPY/NS5R+E6ztJQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
		
		<!-- Bootstrap 5.2.3 -->
		<link href="<?php echo e(URL::asset('plugins/bootstrap-5.2.3-dist/css/bootstrap.min.css')); ?>" rel="stylesheet">

		<!-- Icons -->
		<link href="<?php echo e(URL::asset('styles/icons.css')); ?>" rel="stylesheet" />
		
	 
		
		<!-- Toastr -->
		<link href="<?php echo e(URL::asset('plugins/toas')); ?>" rel="stylesheet" />


		<link href="<?php echo e(URL::asset('plugins/slick/slick.css')); ?>" rel="stylesheet" />
		<link href="<?php echo e(URL::asset('plugins/slick/slick-theme.css')); ?>" rel="stylesheet" />
		<link href="<?php echo e(URL::asset('plugins/aos/aos.css')); ?>" rel="stylesheet" />

		<link href="<?php echo e(URL::asset('styles/style.css')); ?>" rel="stylesheet" />

	</head>

	<body>
		
		<?php if(config('master-frontend.maintenance') == 'on'): ?>

			<?php echo $__env->make('layouts.maintenance', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<?php else: ?>

			<div>
				<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				
					<!--  App-Content -->	
				<main class="main">
					<div class="content-app">
						
						<?php echo $__env->yieldContent('content'); ?>
						
					</div>                   
				</main> <!-- End App-Content -->
				
				<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				
			</div>


		<?php endif; ?>

		<!-- JQuery-->
		<script src="<?php echo e(URL::asset('plugins/jquery/jquery-3.6.0.min.js')); ?>"></script>
		<!-- Bootstrap 5-->
		<script src="<?php echo e(URL::asset('plugins/bootstrap-5.2.3-dist/js/bootstrap.bundle.min.js')); ?>"></script>


		<script src="<?php echo e(URL::asset('plugins/slick/slick.min.js')); ?>"></script>  
		<script src="<?php echo e(URL::asset('plugins/aos/aos.js')); ?>"></script> 
		<script src="<?php echo e(URL::asset('plugins/typed/typed.min.js')); ?>"></script>
		<script src="<?php echo e(URL::asset('js/ikhan.js')); ?>"></script>  


		<script>
			document.addEventListener('DOMContentLoaded', function() {
				var options = {
					strings: [	'<h1><span><?php echo e(__('Article Generator')); ?></span></h1>', 
								'<h1><span><?php echo e(__('Content Improver')); ?></span></h1>',
								'<h1><span><?php echo e(__('Blog Sections')); ?></span></h1>',
								'<h1><span><?php echo e(__('Blog Ideas')); ?></span></h1>',
								'<h1><span><?php echo e(__('SEO Meta Descriptions')); ?></span></h1>',
								'<h1><span><?php echo e(__('FAQ Answers')); ?></span></h1>',
								'<h1><span><?php echo e(__('And Many More!')); ?></span></h1>'
							],
					typeSpeed: 40, // Vitesse de frappe en millisecondes
					backSpeed: 40, // Vitesse de suppression en millisecondes
					backDelay: 2000, // Délai avant le début de la suppression
					startDelay: 500, // Délai avant le début de la frappe
					loop: true ,// Répéter l'animation en boucle
					showCursor:true
				};

				var typed = new Typed("#typed", options);
			});
		</script>
		<!-- Trigger Toast with jQuery -->
		<script>
			$(document).ready(function(){
				$('.toast').toast('show');
			});
		</script>
	</body>
</html>

<?php /**PATH /home/youssef/Desktop/laravel/projects/intelOmega/resources/views/layouts/master-frontend.blade.php ENDPATH**/ ?>