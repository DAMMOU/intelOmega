<div class="container h-100vh">

    <div class="row text-center h-100vh align-items-center">

        <div class="col-md-12">
        
            <img src="<?php echo e(URL::asset('img/files/maintenance.png')); ?>" class="mt-4" style="height: 500px;"  alt="Maintenance Image">
            <h2 class="mt-4 font-weight-bold"><?php echo e(__('We are just tuning up a few things')); ?>.</h2></div>
            <h5><?php echo e(__('We apologize for the inconvenience but')); ?> <span class="text-info"><?php echo e(config('app.name')); ?></span> <?php echo e(__('is currently undergoing planned maintenance')); ?>.</h5>
    
        </div>
    </div>
</div><?php /**PATH /home/youssef/Desktop/laravel/projects/intelOmega/resources/views/layouts/maintenance.blade.php ENDPATH**/ ?>