<?php

namespace App\Http\Controllers;

use App\Models\Blog;
use App\Models\Faq;
use App\Models\Message;
use App\Models\Review;
use App\Models\Setting;
use Exception;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Show home page
     */
    public function index()
    {
        $information = $this->metadataInformation();
        
        $review_exists = Review::count();   
        $reviews = Review::all();

        $count_faqs = Faq::count(); 
        $faqs = Faq::where('status', 'visible')->get();
        $count_blogs = Blog::count(); 
        $blogs = Blog::where('status', 'published')->get();

        
        return view('home', compact('information', 'faqs', 'count_faqs', 'reviews', 'blogs', 'count_blogs'));
    }

    public function contactUs(Request $request){

        /*request()->validate([
            'firstname' => 'required|string',
            'lastname' => 'required|string',
            'email' => 'required|email',
            'phone' => 'required',
            'message' => 'required',
        ]);*/
        try {

            $message = Message::create([
                'firstname' => $request->input('firstname'),
                'lastname' => $request->input('lastname'),
                'email' => $request->input('email'),
                'phone' => $request->input('phone'),
                'message' => $request->input('message'),
            ]);

            return redirect()->back()->with('success', 'Message sent successfully!');

        } catch (Exception $e) {
            dd($e->getMessage());
            return redirect()->back()->with('error', 'Please try again later or contact support. Error Details: ' . $e->getMessage());
        }
    }


    public function metadataInformation()
    {
        $information_rows = ['title', 'author', 'keywords', 'description', 'js', 'css'];
        $information = [];
        $settings = Setting::all();

        foreach ($settings as $setting) {
            if (in_array($setting['name'], $information_rows)) {
                $information[$setting['name']] = $setting['value'];
            }
        }

        return $information;
    }
}
