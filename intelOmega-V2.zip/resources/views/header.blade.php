<section id="main-wrapper">
				
    <div class="relative flex items-top justify-center min-h-screen">

        <div class="container-fluid fixed-top" id="navbar-container">

            <div class="container">
                
                <div class="row">
                    {{-- NAVBAR --}}
                    <nav class="navbar navbar-expand-lg navbar-light w-100" id="navbar-responsive">
                        <a class="navbar-brand" href="{{ route('home') }}"><img id="brand-img"  src="{{ URL::asset('img/brand/logo.png') }}" alt=""></a>
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse section-links" id="navbarNav">
                            <ul class="navbar-nav">
                                <li class="nav-item">
                                    <a class="nav-link scroll active" href="#main-wrapper">{{ __('Home') }}</a>
                                </li>		

                                <li class="nav-item">
                                    <a class="nav-link scroll" href="#prices-wrapper">{{ __('Prices') }}</a>
                                </li>
    
    
                                <li class="nav-item">
                                    <a class="nav-link scroll" href="#blog-wrapper">{{ __('Blogs') }}</a>
                                </li>
                    
                        
                                <li class="nav-item">
                                    <a class="nav-link scroll" href="#faq-wrapper">{{ __('FAQs') }}</a>
                                </li>
                        
                                
                                <li class="nav-item">
                                    <a class="nav-link scroll" href="#contact-wrapper">{{ __('Contact Us') }}</a>
                                </li>
                            
                                
                                <li class="nav-item text-center frontend-buttons">
                                    <div>
                                                
                                        <a href="{{ url('/') }}" class=" btn btn-dark">{{ __('Dashboard') }}</a>
                                                
                                        <a href="{{ url('/') }}" class=" ml-2 btn btn-primary" id="login-button">{{ __('Login') }}</a>
    
                                        <a href="{{ url('/') }}" class="btn btn-dark ">{{ __('Sign Up') }}</a>
                                                    
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </nav>{{-- END NAVBAR --}}
                   
                </div>
            </div>

            @include('layouts.flash')
            
        </div>
    </div>  
    
</section>