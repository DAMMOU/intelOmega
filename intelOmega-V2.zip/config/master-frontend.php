<?php

    return[
        
        'maintenance' => env('FRONTEND_MAINTENANCE', 'off'),
    ];